#include<stdio.h>
#include<string.h>
#include<unistd.h>
#include<time.h>
#include<sys/socket.h>
#include<sys/types.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#define SERVER_IP "127.0.0.1"
#define SERVER_PORT 4000

int main(){
	struct sockaddr_in client, server;
	int sd, clen = sizeof(client);
	char str[512], str1[512] = "Bad Request!!", *ptr;
	time_t t1;
	bzero((char *) &server, sizeof(server));
	server.sin_family = AF_INET;
	server.sin_port = htons(SERVER_PORT);
	server.sin_addr.s_addr = inet_addr(SERVER_IP);

	sd = socket(AF_INET, SOCK_DGRAM, 0);
	bind(sd, (struct sockaddr *) &server, sizeof(server));
	while(1){
		do{
			memset(str, 0x0, 512);
			recvfrom(sd, str, 512, 0, (struct sockaddr *) &client, &clen);
			if(!strcmp(str, "time")){
				t1 = time(NULL);
				ptr = ctime(&t1);
				sendto(sd, ptr, strlen(ptr)+1, 0, (struct sockaddr *) &client, sizeof(client));
			}
			else{
				sendto(sd, str1, strlen(str1)+1, 0, (struct sockaddr *) &client, sizeof(client));
			}
		} while(strcmp(str, "stop"));
	}
}

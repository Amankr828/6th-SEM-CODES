#include<stdio.h>
#include<string.h>
#include<unistd.h>
#include<sys/socket.h>
#include<sys/types.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#define SERVER_IP "127.0.0.1"
#define SERVER_PORT 4000
#define CLIENT_IP "127.0.0.2"
#define CLIENT_PORT 4002

int main(){
	struct sockaddr_in client, server;
	int sd;
	char str[512], str1[512];
	bzero((char *) &server, sizeof(server));
	server.sin_family = AF_INET;
	server.sin_port = htons(SERVER_PORT);
	server.sin_addr.s_addr = inet_addr(SERVER_IP);
	bzero((char *) &client, sizeof(client));
	client.sin_family = AF_INET;
	client.sin_port = htons(CLIENT_PORT);
	client.sin_addr.s_addr = inet_addr(CLIENT_IP);

	sd = socket(AF_INET, SOCK_STREAM, 0);
	connect(sd, (struct sockaddr *) &server, sizeof(server));
	do{
		printf("\n\nEnter a message: ");
		scanf("%s", str);
		send(sd, str, strlen(str)+1, 0);
		memset(str1, 0x0, 512);
		recv(sd, str1, 512, 0);
		printf("Reply Received: %s", str1);
	} while(strcmp(str, "stop"));
	close(sd);
}
